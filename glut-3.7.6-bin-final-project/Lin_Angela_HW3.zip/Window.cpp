#include <iostream>
#include <vector>

#ifdef __APPLE__
    #include <GLUT/glut.h>
#else
    #include <GL/glut.h>
#endif

#include "Window.h"
#include "Cube.h"
#include "Matrix4.h"
#include "Globals.h"
#include "OBJObject.h"

int Window::width  = 512;   //Set window width in pixels here
int Window::height = 512;   //Set window height in pixels here
float dir = 1.0;
Camera camera;
OBJObject *obj;
OBJObject * bunny;
OBJObject * dragon;
OBJObject * bear;
Drawable * drawable;
std::vector<Drawable*>* drawables;
int last;
bool multiple;
bool rasterizing;
int frame = 0, time, timebase = 0;
int draw_item;

void Window::initialize(void)
{
    //Setup the light
    Vector4 lightPos(0.0, 10.0, 15.0, 1.0);
    Globals::light.position = lightPos;
    Globals::light.quadraticAttenuation = 0.02;
    
    //Initialize cube matrix:
    Globals::cube.toWorld.identity();
    
    //Setup the cube's material properties
    Color color(0x23ff27ff);
    Globals::cube.material.color = color;

	obj = 0;
	bunny = 0;
	dragon = 0;
	bear = 0;
	drawable = &(Globals::cube);
	drawables = new std::vector<Drawable*>();
	drawables->push_back(&(Globals::cube));
	last = 0;
	multiple = false;
	rasterizing = false;
	draw_item = 0;
	Globals::rasterizer.level = 1;
	Globals::rasterizer.toDraw = drawables->at(0);
	Globals::rasterizer.debug = false;
}

//----------------------------------------------------------------------------
// Callback method called when system is idle.
// This is called at the start of every new "frame" (qualitatively)
void Window::idleCallback()
{
    //Set up a static time delta for update calls
    Globals::updateData.dt = 1.0/60.0;// 60 fps
    
    //Rotate cube; if it spins too fast try smaller values and vice versa
    Globals::cube.spin(0.0005*dir);
    
    //Call the update function on cube
    Globals::cube.update(Globals::updateData);
	//obj->update(Globals::updateData);
    
	// fps stuff 
	frame++;
	time = glutGet(GLUT_ELAPSED_TIME);
	if (time - timebase > 1000) {
		printf("FPS:%4.2f\n",
		frame*1000.0 / (time - timebase));
		timebase = time;
		frame = 0;
	}

    //Call the display routine to draw the cube
	if (rasterizing) {
		//std::cout << "rasterizing!!" << std::endl;
		Globals::rasterizer.draw(draw_item, Globals::camera, Globals::house);
	}
	else
		displayCallback();
	
}

//----------------------------------------------------------------------------
// Callback method called by GLUT when graphics window is resized by the user
void Window::reshapeCallback(int w, int h)
{
	
	width = w;                                                       //Set the window width
    height = h;                                                      //Set the window height

	Globals::rasterizer.D.makeViewport(0.0, (float)w, 0.0, (float)h);
	Globals::rasterizer.P.makePerspectiveProjection(60.0, w, h, 1.0, 1000.0);
	Globals::rasterizer.resizePixelBuffer(w, h);
	Globals::rasterizer.resizeZBuffer(w, h);

    glViewport(0, 0, w, h);                                          //Set new viewport size
    glMatrixMode(GL_PROJECTION);                                     //Set the OpenGL matrix mode to Projection
    glLoadIdentity();                                                //Clear the projection matrix by loading the identity
    gluPerspective(60.0, double(width)/(double)height, 1.0, 1000.0); //Set perspective projection viewing frustum
}

//----------------------------------------------------------------------------
// Callback method called by GLUT when window readraw is necessary or when glutPostRedisplay() was called.
void Window::displayCallback()
{
	
    //Clear color and depth buffers
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    //Set the OpenGL matrix mode to ModelView
    glMatrixMode(GL_MODELVIEW);
	glLoadMatrixf(camera.getInverseMatrix().ptr());
    
    //Push a matrix save point
    //This will save a copy of the current matrix so that we can
    //make changes to it and 'pop' those changes off later.
    glPushMatrix();
    
    //Replace the current top of the matrix stack with the inverse camera matrix
    //This will convert all world coordiantes into camera coordiantes
    glLoadMatrixf(Globals::camera.getInverseMatrix().ptr());
    
    //Bind the light to slot 0.  We do this after the camera matrix is loaded so that
    //the light position will be treated as world coordiantes
    //(if we didn't the light would move with the camera, why is that?)
    Globals::light.bind(0);
    
    //Draw the cube!
	if (!rasterizing) {
		if (draw_item != 2)
			drawables->at(0)->draw(Globals::drawData);
		else { // draw_item == 2
			drawables->at(1)->draw(Globals::drawData);
			if (draw_item == 2 && multiple) {
				for (int i = 2; i < drawables->size(); i++) {
					drawables->at(i)->draw(Globals::drawData);
				}
			}
		}
	}
	else {
		Globals::rasterizer.draw(draw_item, Globals::camera, Globals::house);
	}

    //Pop off the changes we made to the matrix stack this frame
    glPopMatrix();
    
    //Tell OpenGL to clear any outstanding commands in its command buffer
    //This will make sure that all of our commands are fully executed before
    //we swap buffers and show the user the freshly drawn frame
    glFlush();
    
    //Swap the off-screen buffer (the one we just drew to) with the on-screen buffer
    glutSwapBuffers();
}

void Window::printPosition() {
	Vector3 printv = Vector3(Globals::cube.toWorld.get(3,0), Globals::cube.toWorld.get(3,1), Globals::cube.toWorld.get(3,2));
	printv.print("");
}

//TODO: Keyboard callbacks!
void Window::processNormalKeys(unsigned char key, int x, int y) {
	Matrix4 change;
	int temp_last = last;
	if (draw_item != 2)
		last = 0;

	if (key == 'c') {
		dir = dir * (-1.0);
		if (draw_item == 0)
			printPosition();
	}
	else if (key == 'x') {
		change.makeTranslate(-1.0, 0.0, 0.0);
		//drawable->toWorld = change * drawable->toWorld;
		//drawable->left = change * drawable->left;

		drawables->at(last)->toWorld = change * drawables->at(last)->toWorld;
		drawables->at(last)->left = change * drawables->at(last)->left;
		if (draw_item == 0)
			printPosition();
	}
	else if (key == 'X') {
		change.makeTranslate(1.0, 0.0, 0.0);
		//drawable->toWorld = change * drawable->toWorld;
		//drawable->left = change * drawable->left;

		drawables->at(last)->toWorld = change * drawables->at(last)->toWorld;
		drawables->at(last)->left = change * drawables->at(last)->left;
		if (draw_item == 0)
			printPosition();
	}
	else if (key == 'y') {
		change.makeTranslate(0.0, -1.0, 0.0);
		//drawable->toWorld = change*drawable->toWorld;
		//drawable->left = change * drawable->left;

		drawables->at(last)->toWorld = change*drawables->at(last)->toWorld;
		drawables->at(last)->left = change * drawables->at(last)->left;
		if (draw_item == 0)
			printPosition();
	}
	else if (key == 'Y') {
		change.makeTranslate(0.0, 1.0, 0.0);
		//drawable->toWorld = change*drawable->toWorld;
		//drawable->left = change * drawable->left;

		drawables->at(last)->toWorld = change*drawables->at(last)->toWorld;
		drawables->at(last)->left = change * drawables->at(last)->left;
		if (draw_item == 0)
			printPosition();
	}
	else if (key == 'z') {
		change.makeTranslate(0.0, 0.0, -1.0);
		//drawable->toWorld = change*drawable->toWorld;
		//drawable->left = change * drawable->left;

		drawables->at(last)->toWorld = change*drawables->at(last)->toWorld;
		drawables->at(last)->left = change *drawables->at(last)->left;
		if (draw_item == 0)
			printPosition();
	}
	else if (key == 'Z') {
		change.makeTranslate(0.0, 0.0, 1.0);
		//drawable->toWorld = change*drawable->toWorld;
		//drawable->left = change * drawable->left;

		drawables->at(last)->toWorld = change*drawables->at(last)->toWorld;
		drawables->at(last)->left = change * drawables->at(last)->left;
		if (draw_item == 0)
			printPosition();
	}
	else if (key == 'r') {
		change.identity();
		//drawable->toWorld = drawable->toWorld * drawable->right.inverse();
		//drawable->toWorld = drawable->left.inverse() * drawable->toWorld;
		//drawable->right.identity();
		//drawable->left.identity();

		drawables->at(last)->toWorld = drawables->at(last)->toWorld * drawables->at(last)->right.inverse();
		drawables->at(last)->toWorld = drawables->at(last)->left.inverse() * drawables->at(last)->toWorld;
		drawables->at(last)->right.identity();
		drawables->at(last)->left.identity();

		if (draw_item == 0)
			printPosition();
		
	}
	else if (key == 'o') {
		change.makeRotateArbitrary(Vector3(0.0, 0.0, 1.0), 0.5);
		//drawable->toWorld = change*drawable->toWorld;
		//drawable->left = change * drawable->left;

		drawables->at(last)->toWorld = change*drawables->at(last)->toWorld;
		drawables->at(last)->left = change * drawables->at(last)->left;
		if (draw_item == 0)
			printPosition();
	}
	else if (key == 'O') {
		change.makeRotateArbitrary(Vector3(0.0, 0.0, 1.0), -0.5);
		//drawable->toWorld = change*drawable->toWorld;
		//drawable->left = change * drawable->left;

		drawables->at(last)->toWorld = change*drawables->at(last)->toWorld;
		drawables->at(last)->left = change * drawables->at(last)->left;
		if (draw_item == 0)
			printPosition();
	}
	else if (key == 's') {
		change.makeScale(0.75);
		//drawable->toWorld = drawable->toWorld * change;
		//drawable->right = drawable->right * change;

		drawables->at(last)->toWorld = drawables->at(last)->toWorld * change;
		drawables->at(last)->right = drawables->at(last)->right * change;
		if (draw_item == 0)
			printPosition();
	}
	else if (key == 'S') {
		change.makeScale(1.25);
		//drawable->toWorld = drawable->toWorld * change;
		//drawable->right = drawable->right * change;

		drawables->at(last)->toWorld = drawables->at(last)->toWorld * change;
		drawables->at(last)->right = drawables->at(last)->right * change;
		if (draw_item == 0)
			printPosition();
	}
	else if (key == 'm') {
		if (draw_item != 2)
			return;
		if (multiple == false) {
			multiple = true;
			std::cout << "doing multiple objs now" << std::endl;
		}
		else {
			multiple = false;
			if (drawables->size() > 2) {
				for (int i = 2; i < drawables->size(); i++) {
					drawables->pop_back();
				}
			}
			std::cout << "not doing multiple objs anymore" << std::endl;
		}
		
	}
	else if (key == 'e') {
		rasterizing = !(rasterizing);
		std::cout << "rasterizing is " << rasterizing << "!" << std::endl;
	}
	else if (key == '+') {
		if (Globals::rasterizer.level < 4)
			Globals::rasterizer.level++;
		std::cout << "Pressed key '+', now at Part " << Globals::rasterizer.level << std::endl;
	}
	else if (key == '-') {
		if (Globals::rasterizer.level > 1)
			Globals::rasterizer.level--;
		std::cout << "Pressed key '-', now at Part " << Globals::rasterizer.level << std::endl;
	}
	else if (key == 'd') {
		if (Globals::rasterizer.debug == false ){
			Globals::rasterizer.debug = true;
			std::cout << "Debug mode ON" << std::endl;
		}
		else {
			Globals::rasterizer.debug = false;
			std::cout << "Debug mode OFF" << std::endl;
		}
	}
	last = temp_last;
}

//TODO: Function Key callbacks!
void Window::processFunctionKeys(int key, int x, int y) {
	if (key == GLUT_KEY_F1) {
		glEnable(GL_LIGHTING);
		draw_item = 0;
		Globals::camera = Camera();
		//drawable = &(Globals::cube);
		drawables->at(0) = &(Globals::cube);
		Globals::rasterizer.toDraw = drawables->at(0);
	}
	else if (key == GLUT_KEY_F2) {
		Globals::camera.set(Vector3(0.0, 24.14, 24.14), Vector3(0.0, 0.0, 0.0), Vector3(0.0, 1.0, 0.0));
		glDisable(GL_LIGHTING);
		draw_item = 1;
		//drawable = &(Globals::house);
		drawables->at(0) = &(Globals::house);
		Globals::rasterizer.toDraw = drawables->at(0);
	}
	else if (key == GLUT_KEY_F3) {
		Globals::camera.set(Vector3(-28.33, 11.66, 23.33), Vector3(-5.0, 0.0, 0.0), Vector3(0.0, 1.0, 0.5));
		glDisable(GL_LIGHTING);
		draw_item = 1;
		//drawable = &(Globals::house);
		drawables->at(0) = &(Globals::house);
		Globals::rasterizer.toDraw = drawables->at(0);
	}
	else if (key == GLUT_KEY_F4) {	// bunny
		glEnable(GL_LIGHTING);
		Globals::camera = Camera();
		if (multiple) {
			drawables->push_back(new OBJObject("../bunny.obj"));
			last++;
			std::cout << "+1 bunny" << std::endl;
		}
		else {
			if (bunny == 0) {
				bunny = new OBJObject("../bunny.obj");
			}
			if (drawables->size() == 1)
				drawables->push_back(bunny);
			else
				drawables->at(1) = bunny;
			last = 1;
			Globals::rasterizer.toDraw = drawables->at(1);
		}
		draw_item = 2;
	}
	else if (key == GLUT_KEY_F5) {	// dragon
		glEnable(GL_LIGHTING);
		Globals::camera = Camera();
		if (multiple) {
			drawables->push_back(new OBJObject("../dragon.obj"));
			last++;
			std::cout << "+1 dragon" << std::endl;
		}
		else {
			if (dragon == 0) {
				dragon = new OBJObject("../dragon.obj");
			}
			if (drawables->size() == 1)
				drawables->push_back(dragon);
			else
				drawables->at(1) = dragon;
			last = 1;
			Globals::rasterizer.toDraw = drawables->at(1);
		}
		draw_item = 2;
	}
	else if (key == GLUT_KEY_F6) {	// bear
		glEnable(GL_LIGHTING);
		Globals::camera = Camera();
		if (multiple) {
			drawables->push_back(new OBJObject("../bear.obj"));
			last++;
			std::cout << "+1 bear" << std::endl;
		}
		else {
			if (bear == 0) {
				bear = new OBJObject("../bear.obj");
			}
			if (drawables->size() == 1)
				drawables->push_back(bear);
			else
				drawables->at(1) = bear;
			last = 1;
			Globals::rasterizer.toDraw = drawables->at(1);
		}
		draw_item = 2;
	}
	else {}
}


//TODO: Mouse callbacks!

//TODO: Mouse Motion callbacks!







Window::~Window()
{
	//Delete any dynamically allocated memory/objects here
	if (drawables->size() > 1) {
		for (int i = 1; i < drawables->size(); i++) {
			delete drawables->at(i);
		}
	}
	
}